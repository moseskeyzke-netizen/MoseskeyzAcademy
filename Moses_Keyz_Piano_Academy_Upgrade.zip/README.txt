MOSES KEYZ PIANO ACADEMY — WEBSITE UPDATE
Upload these files to the ROOT of your existing GitHub repository:
- index.html
- manifest.webmanifest
- sw.js

The website includes:
- Beginner piano lessons
- All 12 major keys (chord note guides)
- Clickable on-screen piano with generated tones
- Gospel progression I–V–vi–IV demo
- Practice quiz
- WhatsApp contact button (enter your number in the Academy section)
- Clearly labelled ad placeholders

IMPORTANT:
- Ad placeholders are not live advertisements and do not generate revenue.
- To show real ads, apply to an advertising provider such as Google AdSense, pass its review, and add the exact ad code it gives you.
- Premium payments are not connected. Set up a secure payment provider before accepting payments.
- Replace the files in your GitHub repository root, then commit changes. GitHub Pages will redeploy automatically.
